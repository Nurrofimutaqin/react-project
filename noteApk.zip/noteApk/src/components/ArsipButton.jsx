import React from 'react';
 
function ArsipButton() {
  return <button className='note-item__archive-button' >Arsip</button>
}
 
export default ArsipButton;