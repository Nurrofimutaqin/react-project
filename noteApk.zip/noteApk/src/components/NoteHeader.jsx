import React from "react";

function NoteHeader(){

        return (
            <div className="note-app__header">
                <h1>Notes</h1>
                <form action="">
                    <input type="text" placeholder="Cari Catatan.."/>
                </form>
            </div>
        )

}
export default NoteHeader;
