import React from 'react';
 
function NoteEmpty() {
    return <>
    <div className="notes-list__empty-message">tidak ada catatan</div>
    </>
}
 
export default NoteEmpty;